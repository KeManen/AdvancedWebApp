let myName: string

myName = "John Doe"
//myName = 666

console.log(myName)

function f(a: number = 0, b: number = 0): number {
    return a + b
}

console.log(f(10))

type YourName = string

let yourName: YourName

yourName = "Camilla Young"

type User = {
    readonly id: number,
    email: string,
    username?: string    
}

let user: User = {
    id: 666,
    email: "foo@bar.baz"
}

user.email ="mail@mail.com"
//user.id = 667

console.log(user)